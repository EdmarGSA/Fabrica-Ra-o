import React from 'react';

const Header = ({ title }) => (
  <header className="bg-green-700 text-white p-4 shadow-md text-center text-xl font-bold">
    {title}
  </header>
);

export default Header;