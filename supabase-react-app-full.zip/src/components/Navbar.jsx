import React from 'react';

const Navbar = () => (
  <nav className="bg-white border-t border-gray-200 fixed bottom-0 w-full flex justify-around p-2 shadow-inner">
    <button className="text-green-700 font-semibold">Dashboard</button>
    <button className="text-green-700 font-semibold">Produção</button>
    <button className="text-green-700 font-semibold">Financeiro</button>
  </nav>
);

export default Navbar;