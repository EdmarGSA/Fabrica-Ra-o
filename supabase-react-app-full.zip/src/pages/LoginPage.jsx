import React from 'react';

const LoginPage = () => (
  <div className="flex items-center justify-center min-h-screen bg-green-100">
    <div className="bg-white p-6 rounded shadow-md w-full max-w-md">
      <h2 className="text-center text-2xl font-bold text-green-700">Login</h2>
      <form className="mt-4 space-y-4">
        <input type="email" placeholder="E-mail" className="w-full p-2 border rounded" />
        <input type="password" placeholder="Senha" className="w-full p-2 border rounded" />
        <button type="submit" className="w-full bg-green-600 text-white p-2 rounded hover:bg-green-700">Entrar</button>
      </form>
    </div>
  </div>
);

export default LoginPage;