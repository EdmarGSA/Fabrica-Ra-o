import React from 'react';

const Dashboard = () => (
  <div className="p-4">
    <h1 className="text-2xl font-bold text-green-700">Painel Principal</h1>
    <p className="mt-2 text-gray-600">Bem-vindo ao sistema de gestão da Fábrica de Ração.</p>
  </div>
);

export default Dashboard;