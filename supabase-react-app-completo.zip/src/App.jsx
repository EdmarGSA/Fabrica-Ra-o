import { useEffect, useState } from "react";
import { supabase } from "./supabase/client";

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => setUser(user));
    const { data: listener } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user || null);
    });
    return () => listener?.subscription.unsubscribe();
  }, []);

  const handleLogin = async () => {
    await supabase.auth.signInWithOtp({ email: prompt("Digite seu e-mail") });
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 flex-col gap-4">
      {user ? (
        <>
          <h1 className="text-2xl font-bold">Olá, {user.email}</h1>
          <button onClick={handleLogout} className="bg-red-600 text-white px-4 py-2 rounded">Sair</button>
        </>
      ) : (
        <>
          <h1 className="text-2xl font-bold">Bem-vindo!</h1>
          <button onClick={handleLogin} className="bg-green-600 text-white px-4 py-2 rounded">Entrar com E-mail</button>
        </>
      )}
    </div>
  );
}

export default App;
