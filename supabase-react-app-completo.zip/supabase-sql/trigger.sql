create table if not exists user_profiles (
  id uuid primary key references auth.users on delete cascade,
  email text unique,
  name text,
  role text default 'user',
  created_at timestamp with time zone default timezone('utc'::text, now())
);

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.user_profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();