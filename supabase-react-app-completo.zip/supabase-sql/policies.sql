-- Enable Row Level Security
alter table user_profiles enable row level security;

-- Policy: read own profile
create policy "Can read own profile"
on user_profiles
for select
using (auth.uid() = id);

-- Policy: update own profile
create policy "Can update own profile"
on user_profiles
for update
using (auth.uid() = id);