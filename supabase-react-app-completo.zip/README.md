# Supabase + React App

Este projeto é um painel básico com autenticação utilizando Supabase + React + Tailwind CSS. Está preparado para deploy na **Vercel** e inclui:

✅ Login e Registro com Supabase Auth  
✅ Persistência de sessão com `@supabase/auth-helpers`  
✅ Componentes de layout (`Header`, `Navbar`)  
✅ Dashboard inicial  
✅ Scripts SQL para tabela `user_profiles`, triggers e RLS  
✅ Pronto para integração com GitHub e Vercel  

## 🔧 Como rodar localmente

1. Instale as dependências:
```bash
npm install
```

2. Crie um arquivo `.env.local` na raiz:
```env
VITE_SUPABASE_URL=https://<sua-instancia>.supabase.co
VITE_SUPABASE_ANON_KEY=chave-anonima
```

3. Rode o projeto:
```bash
npm run dev
```

## 🚀 Deploy na Vercel

1. Vá em [vercel.com](https://vercel.com/import)
2. Conecte seu repositório GitHub
3. Configure as variáveis de ambiente:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

## 📦 Scripts SQL

Veja a pasta `supabase-sql/` para scripts de:
- Criação da tabela `user_profiles`
- Trigger automática
- Políticas RLS

## 📃 Licença

MIT
